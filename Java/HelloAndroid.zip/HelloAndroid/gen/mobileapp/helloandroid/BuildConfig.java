/** Automatically generated file. DO NOT MODIFY */
package mobileapp.helloandroid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}