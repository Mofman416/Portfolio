/** Automatically generated file. DO NOT MODIFY */
package mobileap.photoalbum;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}