import java.util.Calendar;


public class ShowTime{//start class
	public static void main(String[] args){
		System.out.println(Calendar.getInstance().getTime());
	
	}

}//end class