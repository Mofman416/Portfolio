/** Automatically generated file. DO NOT MODIFY */
package mobileapp.ch20act;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}