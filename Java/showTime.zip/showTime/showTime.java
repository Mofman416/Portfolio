import java.util.Calendar;

/*
Mofman416
1/19
show current time in console
*/

public class showTime{//start class
	public static void main(String[] args){
		System.out.println(Calendar.getInstance().getTime());
	
	}

}//end class