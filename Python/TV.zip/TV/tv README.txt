This is a program made to replecate a TV program.

The user can see the current volume and channel settings.

They can also set the volume and channel, and the status will update to show the settings the put.