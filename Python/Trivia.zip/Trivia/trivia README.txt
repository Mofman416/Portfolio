This is the trivia program made for a class project.

The program creates the category, question, potential responses, answers, and an explanation 10
times.

It keeps track of the user's score and returns it after the program has completed its run.