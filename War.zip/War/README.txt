The finished War game made by me, Cameron Murphy, Nicholaus Whites, Jessica Weinburger.

Further information is in the docstrings in the program.