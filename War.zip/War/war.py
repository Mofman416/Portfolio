#Michael Freeman, Cameron Murphy, Nicholaus Whites, Jessica Weinburger
#2/19
#War
#Python 4th

import cards, games

class W_Card(cards.Card):
    ACE_VALUE = 14
    KING_VALUE = 13
    QUEEN_VALUE = 12
    JACK_VALUE = 11

class W_Deck(cards.Deck):

    def populate(self):
        for suit in W_Card.SUITS:
            for rank in W_Card.RANKS:
                self.cards.append(W_Card(rank, suit))


class W_Hand(cards.Hand):

    def __init__(self, name):
        super(W_Hand, self).__init__()
        self.name = name

    def __str__(self):
        rep = self.name + ":\t" + super(W_Hand, self).__str__()
        if self.total:
            rep += "(" + str(self.total) + ")"
        return rep



class W_Player(W_Hand):
    """ A War Player. """

    def lose(self):
        print(self.name, "loses.")

    def win(self):
        print(self.name, "wins.")

class Field(W_Hand):
    """This is where the cards in a war scenario go."""

    def check_cards(self):
        if W_Player.total() > W_Computer.total():
            print("Player wins!")
            self.give(Field, Pot)
        elif W_Player.total() < W_Computer.total():
            print("Computer wins.")
            self.give(Field, Pot)

class W_Computer(W_Hand):
    """ A War Computer. """

    def lose(self):
        print(self.name, "loses.")

    def win(self):
        print(self.name, "wins.")

class Pot(W_Hand):
    """Where the wild cards are."""

    if victor = 0:
        self.give(Pot, W_Player)
    elif victor = 1:
        self.give(Pot, W_Computer)

class W_Game(object):
    """ A War Game. """

    def __init__(self,):
        self.players = []


        self.deck = W_Deck()
        self.deck.populate()
        self.deck.shuffle()

    @property

    def __additional_cards(self, player):
        print("Yeay")
        self.deck.deal([player])
        print(player)

    def play(self):
        print("Yes")
        # deal initial 2 cards to everyone
        self.deck.deal(self.players, 26)
        for player in self.players:
            print(player)

        for player in self.players:
            self.__additional_cards(player)

    def War(self):
        print("War!")
        table = []



        # remove everyone's cards
        for player in self.players:
            player.clear()
        self.dealer.clear()

def main():
    print("Testing")
    game = W_Game()
    game.play()

main()
